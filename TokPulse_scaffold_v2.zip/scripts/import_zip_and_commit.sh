#!/usr/bin/env bash
set -euo pipefail
ZIP_PATH="${1:-}"
if [[ -z "$ZIP_PATH" || ! -f "$ZIP_PATH" ]]; then
  echo "Usage: $0 /path/to/TokPulse_scaffold_v2.zip"
  exit 1
fi
unzip -o "$ZIP_PATH" -d . >/dev/null
git add -A
git commit -m "feat(tokpulse): import v2 scaffold"
git push origin main
