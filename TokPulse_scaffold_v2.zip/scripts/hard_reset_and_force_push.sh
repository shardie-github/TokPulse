#!/usr/bin/env bash
set -euo pipefail
# Safeguarded reset preserving a backup branch+tag
backup=pre_tokpulse_$(date +%Y%m%d_%H%M%S)
git fetch origin
git checkout main
git pull --rebase
git branch "$backup"
git tag "$backup"
echo "[reset] Backup created: $backup"
echo "[reset] Now you can overwrite files (e.g., unzip) and then run:"
echo "git add -A && git commit -m 'feat(tokpulse): reset to v2 scaffold' && git push origin main --force-with-lease"
