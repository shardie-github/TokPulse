#!/usr/bin/env bash
set -euo pipefail
echo "[dev_bootstrap] init…"
mkdir -p .tokpulse exports secrets
python3 -m venv .venv || true
source .venv/bin/activate
python -m pip install --upgrade pip
pip install -e packages/tokpulse-core -e packages/tokpulse-adapters -e packages/tokpulse-pipelines -e packages/tokpulse-exporters -e apps/tokpulse-admin
echo "[dev_bootstrap] complete."
