# TokPulse v2 — Ads Ingestion & Creative Ops (Monorepo-Ready)

**Date:** 2025-09-27

### What’s new in v2
- TikTok pipelines for **campaigns, adgroups, ads, creatives, daily metrics** with pagination + robust retry.
- **Meta** stubs for parity (easily enable later).
- **Postgres** and **BigQuery** writers (opt-in via `.env`).
- **Discord/Slack** alert hooks for failures + run summaries.
- Richer **Admin** (`/health`, `/runs/latest`, `/exports`, `/metrics`).
- Import helpers: `scripts/hard_reset_and_force_push.sh` & `scripts/import_zip_and_commit.sh`.

## Quickstart
```bash
bash scripts/dev_bootstrap.sh
source .venv/bin/activate
cp .env.example .env && nano .env

# OAuth
python -m tokpulse_core.oauth.print_auth_url
python -m tokpulse_core.oauth.exchange_code --code YOUR_CODE

# Run all pulls (last 7 days)
python -m tokpulse_pipelines.pull_all
uvicorn tokpulse_admin.main:app --host 0.0.0.0 --port 8080
```

## Cron
Use `config/cron/crontab.example` (06:00 refresh, 06:05 pulls, etc.).
