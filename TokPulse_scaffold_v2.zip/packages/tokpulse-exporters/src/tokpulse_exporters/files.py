import os, pandas as pd, json
from tokpulse_core.config import SETTINGS

def export_csv(df: pd.DataFrame, name: str):
    os.makedirs(SETTINGS.export_dir, exist_ok=True)
    path = os.path.join(SETTINGS.export_dir, f"{name}.csv")
    df.to_csv(path, index=False)
    return path

def export_json(df: pd.DataFrame, name: str):
    os.makedirs(SETTINGS.export_dir, exist_ok=True)
    path = os.path.join(SETTINGS.export_dir, f"{name}.json")
    df.to_json(path, orient="records")
    return path
