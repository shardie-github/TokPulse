import gspread, pandas as pd
from oauth2client.service_account import ServiceAccountCredentials
from tokpulse_core.config import SETTINGS

def _client():
    scopes = ['https://www.googleapis.com/auth/spreadsheets']
    creds = ServiceAccountCredentials.from_json_keyfile_name(SETTINGS.sheets_service_account_json, scopes)
    return gspread.authorize(creds)

def upsert_sheet(df: pd.DataFrame, worksheet: str):
    gc = _client()
    sh = gc.open_by_key(SETTINGS.sheets_spreadsheet_id)
    try:
        ws = sh.worksheet(worksheet)
    except:
        ws = sh.add_worksheet(title=worksheet, rows=str(max(1000, len(df)+10)), cols=str(len(df.columns)+2))
    ws.clear()
    ws.update([df.columns.tolist()] + df.values.tolist())
