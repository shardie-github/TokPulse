import pandas as pd, datetime as dt
from tokpulse_adapters.tiktok_client import TikTokClient
from tokpulse_exporters.files import export_csv, export_json
from tokpulse_exporters.sheets import upsert_sheet
from tokpulse_pipelines._util import write_warehouse
from tokpulse_core.logging import get_logger
from tokpulse_core.alerts import discord, slack

log = get_logger("pipeline.ads")

def run(days:int=7):
    end = dt.date.today()
    start = end - dt.timedelta(days=days)
    cli = TikTokClient()
    j = cli.report_ads(start.isoformat(), end.isoformat())
    data = j.get("data", {}).get("list", [])
    if not data:
        log.info("No ads metrics returned.")
        return pd.DataFrame()
    rows = []
    for it in data:
        rows.append({
            "date": it.get("stat_time_day"),
            "ad_id": str(it.get("ad_id")),
            "impressions": int(it.get("impressions",0)),
            "clicks": int(it.get("clicks",0)),
            "spend": float(it.get("spend",0.0)),
            "conversions": int(it.get("conversions",0)),
            "revenue": float(it.get("revenue",0.0)),
        })
    df = pd.DataFrame(rows)
    write_warehouse(df, "ads_performance")
    export_csv(df, f"ads_performance_{start}_{end}")
    export_json(df, f"ads_performance_{start}_{end}")
    try:
        upsert_sheet(df, "ads_performance")
    except Exception as e:
        log.warning("Sheets export failed: %s", e)
    slack(f"TokPulse: ads metrics {len(df)} rows {start}..{end}")
    discord(f"TokPulse: ads metrics {len(df)} rows {start}..{end}")
    log.info("Ads performance pull complete: %s rows", len(df))
    return df

if __name__ == "__main__":
    run()
