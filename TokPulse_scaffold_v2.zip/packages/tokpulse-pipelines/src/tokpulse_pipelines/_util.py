import os, sqlite3, pandas as pd
from tokpulse_core.config import SETTINGS
from google.cloud import bigquery
import psycopg2

def ensure_sqlite():
    os.makedirs(os.path.dirname(SETTINGS.sqlite_path), exist_ok=True)
    return sqlite3.connect(SETTINGS.sqlite_path)

def upsert_df(con, table: str, df: pd.DataFrame, unique: list[str]):
    if df.empty: return
    tmp = f"tmp_{table}"
    df.to_sql(tmp, con, if_exists="replace", index=False)
    cols = ", ".join(df.columns)
    updates = ", ".join([f"{c}=excluded.{c}" for c in df.columns if c not in unique])
    key = ", ".join(unique)
    con.execute(f"CREATE TABLE IF NOT EXISTS {table} AS SELECT * FROM {tmp} WHERE 0")
    con.execute(f"INSERT INTO {table}({cols}) SELECT {cols} FROM {tmp} ON CONFLICT({key}) DO UPDATE SET {updates}")
    con.execute(f"DROP TABLE {tmp}")
    con.commit()

def write_warehouse(df: pd.DataFrame, table: str):
    if SETTINGS.warehouse_backend == "sqlite":
        con = ensure_sqlite()
        upsert_df(con, table, df, df.columns[:1].tolist())  # naive unique
    elif SETTINGS.warehouse_backend == "bigquery":
        client = bigquery.Client(project=SETTINGS.bq_project)
        table_id = f"{SETTINGS.bq_project}.{SETTINGS.bq_dataset}.{table}"
        job = client.load_table_from_dataframe(df, table_id)
        job.result()
    elif SETTINGS.warehouse_backend == "postgres":
        con = psycopg2.connect(SETTINGS.pg_dsn)
        cur = con.cursor()
        # naive: create table if not exists, then copy via CSV approach
        cols = ", ".join([f"{c} TEXT" for c in df.columns])
        cur.execute(f"CREATE TABLE IF NOT EXISTS {table} ({cols});")
        # upsert left as exercise; keep simple insert for now
        for _, row in df.iterrows():
            vals = ", ".join(["%s"]*len(row))
            cur.execute(f"INSERT INTO {table} VALUES ({vals});", list(map(str,row.values)))
        con.commit()
        cur.close(); con.close()
