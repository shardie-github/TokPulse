from tokpulse_pipelines.pull_ads_metrics import run as ads_metrics
from tokpulse_pipelines.pull_entities import pull_campaigns, pull_adgroups, pull_ads, pull_creatives
from tokpulse_core.logging import get_logger
from tokpulse_core.alerts import slack, discord
log = get_logger("pipeline.all")

if __name__ == "__main__":
    try:
        c = pull_campaigns()
        ag = pull_adgroups()
        a = pull_ads()
        cr = pull_creatives()
        m = ads_metrics(days=7)
        log.info("All pulls done.")
        slack("TokPulse: all pulls complete ✅")
        discord("TokPulse: all pulls complete ✅")
    except Exception as e:
        log.exception("TokPulse run failed: %s", e)
        slack(f"TokPulse: run failed ❌ {e}")
        discord(f"TokPulse: run failed ❌ {e}")
        raise
