import pandas as pd
from tokpulse_adapters.tiktok_client import TikTokClient
from tokpulse_pipelines._util import write_warehouse
from tokpulse_exporters.files import export_csv, export_json
from tokpulse_core.logging import get_logger
log = get_logger("pipeline.entities")

def pull_campaigns():
    cli = TikTokClient()
    rows = list(cli.campaigns())
    df = pd.DataFrame(rows)
    if not df.empty:
        write_warehouse(df, "campaigns")
        export_csv(df, "campaigns")
        export_json(df, "campaigns")
    log.info("campaigns: %s", len(df))
    return df

def pull_adgroups():
    cli = TikTokClient()
    rows = list(cli.adgroups())
    df = pd.DataFrame(rows)
    if not df.empty:
        write_warehouse(df, "adgroups")
        export_csv(df, "adgroups")
        export_json(df, "adgroups")
    log.info("adgroups: %s", len(df))
    return df

def pull_ads():
    cli = TikTokClient()
    rows = list(cli.ads())
    df = pd.DataFrame(rows)
    if not df.empty:
        write_warehouse(df, "ads")
        export_csv(df, "ads")
        export_json(df, "ads")
    log.info("ads: %s", len(df))
    return df

def pull_creatives():
    cli = TikTokClient()
    rows = list(cli.creatives())
    df = pd.DataFrame(rows)
    if not df.empty:
        write_warehouse(df, "creatives")
        export_csv(df, "creatives")
        export_json(df, "creatives")
    log.info("creatives: %s", len(df))
    return df

if __name__ == "__main__":
    pull_campaigns(); pull_adgroups(); pull_ads(); pull_creatives()
