# Minimal Meta parity stubs (extend later)
from tokpulse_core.logging import get_logger
log = get_logger("meta")

class MetaClient:
    def __init__(self, access_token: str, ad_account_id: str):
        self.access_token = access_token
        self.ad_account_id = ad_account_id
    def campaigns(self):
        log.info("Meta campaigns stub")
        return []
