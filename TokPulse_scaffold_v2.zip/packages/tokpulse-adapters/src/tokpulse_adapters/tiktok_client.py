import requests, time
from typing import Dict, Any, Iterable, List
from tokpulse_core.config import SETTINGS
from tokpulse_core.oauth.store_sqlite import TokenStore
from tokpulse_core.retry_backoff import retry
from tokpulse_core.logging import get_logger

log = get_logger("tiktok")

class TikTokClient:
    BASE = "https://business-api.tiktok.com/open_api/v1.3"

    def __init__(self):
        self.store = TokenStore(SETTINGS.token_store_path)

    def _headers(self) -> Dict[str,str]:
        tok = self.store.get("tiktok_token") or {}
        access = tok.get("access_token","")
        return {"Access-Token": access, "Content-Type": "application/json"}

    def _get(self, path: str, params: Dict[str, Any]):
        def call():
            r = requests.get(f"{self.BASE}{path}", headers=self._headers(), params=params, timeout=60)
            if r.status_code in (429, 502, 503):
                raise RuntimeError(f"transient_{r.status_code}")
            r.raise_for_status()
            return r.json()
        return retry(call, on_error=lambda e,i: log.warning("Retry %s on %s", i, e))

    def _paginate(self, path: str, params: Dict[str, Any], list_key: str="list", cursor_key: str="cursor") -> Iterable[Dict[str, Any]]:
        cursor = None
        while True:
            q = {**params}
            if cursor: q["cursor"] = cursor
            data = self._get(path, q).get("data", {})
            items = data.get(list_key, [])
            for it in items:
                yield it
            cursor = data.get(cursor_key)
            if not cursor:
                break

    # Reports
    def report_ads(self, start_date: str, end_date: str):
        return self._get("/report/advertiser/get/", {
            "advertiser_id": SETTINGS.tiktok_advertiser_id,
            "report_type": "BASIC",
            "data_level": "AUCTION_AD",
            "dimensions": ["stat_time_day","ad_id"],
            "metrics": ["impressions","clicks","spend","conversions"],
            "start_date": start_date,
            "end_date": end_date
        })

    # Entities (basic examples)
    def campaigns(self) -> Iterable[Dict[str,Any]]:
        yield from self._paginate("/campaign/get/", {"advertiser_id": SETTINGS.tiktok_advertiser_id})

    def adgroups(self) -> Iterable[Dict[str,Any]]:
        yield from self._paginate("/adgroup/get/", {"advertiser_id": SETTINGS.tiktok_advertiser_id})

    def ads(self) -> Iterable[Dict[str,Any]]:
        yield from self._paginate("/ad/get/", {"advertiser_id": SETTINGS.tiktok_advertiser_id})

    def creatives(self) -> Iterable[Dict[str,Any]]:
        yield from self._paginate("/creative/get/", {"advertiser_id": SETTINGS.tiktok_advertiser_id})
