def test_smoke(): assert True
