from pydantic import BaseModel, Field
from dotenv import load_dotenv
import os
load_dotenv()

class Settings(BaseModel):
    tiktok_app_id: str = os.getenv("TIKTOK_APP_ID","")
    tiktok_app_secret: str = os.getenv("TIKTOK_APP_SECRET","")
    tiktok_redirect_uri: str = os.getenv("TIKTOK_REDIRECT_URI","")
    tiktok_advertiser_id: str = os.getenv("TIKTOK_ADVERTISER_ID","")
    meta_access_token: str = os.getenv("META_ACCESS_TOKEN","")
    meta_ad_account_id: str = os.getenv("META_AD_ACCOUNT_ID","")
    token_store_backend: str = os.getenv("TOKEN_STORE_BACKEND","sqlite")
    token_store_path: str = os.getenv("TOKEN_STORE_PATH",".tokpulse/tokens.db")
    token_refresh_buffer_min: int = int(os.getenv("TOKEN_REFRESH_BUFFER_MIN","30"))
    tz: str = os.getenv("TZ","America/Toronto")
    daily_pull_hour: int = int(os.getenv("DAILY_PULL_HOUR","6"))
    daily_pull_minute: int = int(os.getenv("DAILY_PULL_MINUTE","5"))
    warehouse_backend: str = os.getenv("WAREHOUSE_BACKEND","sqlite")
    sqlite_path: str = os.getenv("SQLITE_PATH",".tokpulse/tokpulse.db")
    bq_project: str = os.getenv("BQ_PROJECT","")
    bq_dataset: str = os.getenv("BQ_DATASET","tokpulse")
    pg_dsn: str = os.getenv("PG_DSN","")
    export_dir: str = os.getenv("EXPORT_DIR","./exports")
    sheets_service_account_json: str = os.getenv("SHEETS_SERVICE_ACCOUNT_JSON","./secrets/gsheets_service.json")
    sheets_spreadsheet_id: str = os.getenv("SHEETS_SPREADSHEET_ID","")
    discord_webhook_url: str = os.getenv("DISCORD_WEBHOOK_URL","")
    slack_webhook_url: str = os.getenv("SLACK_WEBHOOK_URL","")

SETTINGS = Settings()
