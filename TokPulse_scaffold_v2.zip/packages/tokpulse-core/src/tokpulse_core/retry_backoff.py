import time
def retry(call, retries=5, base=0.5, factor=2.0, on_error=None):
    for i in range(retries):
        try:
            return call()
        except Exception as e:
            if on_error: on_error(e, i)
            if i == retries-1: raise
            time.sleep(base * (factor ** i))
