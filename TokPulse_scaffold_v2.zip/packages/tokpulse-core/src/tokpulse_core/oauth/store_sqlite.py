import sqlite3, os, json
from typing import Optional, Dict

class TokenStore:
    def __init__(self, path: str):
        os.makedirs(os.path.dirname(path), exist_ok=True)
        self.path = path
        with sqlite3.connect(self.path) as con:
            con.execute("CREATE TABLE IF NOT EXISTS tokens (k TEXT PRIMARY KEY, v TEXT NOT NULL)")

    def set(self, key: str, data: Dict):
        with sqlite3.connect(self.path) as con:
            con.execute("REPLACE INTO tokens(k, v) VALUES(?, ?)", (key, json.dumps(data)))

    def get(self, key: str) -> Optional[Dict]:
        with sqlite3.connect(self.path) as con:
            cur = con.execute("SELECT v FROM tokens WHERE k=?", (key,))
            row = cur.fetchone()
            return json.loads(row[0]) if row else None
