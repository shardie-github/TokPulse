from tokpulse_core.config import SETTINGS
from urllib.parse import urlencode
params = {
    "app_id": SETTINGS.tiktok_app_id,
    "redirect_uri": SETTINGS.tiktok_redirect_uri,
    "state": "tokpulse",
    "scope": "ad.manage ad.report",
    "response_type": "code",
}
print("https://business-api.tiktok.com/portal/auth?" + urlencode(params))
