import time, requests
from tokpulse_core.config import SETTINGS
from tokpulse_core.oauth.store_sqlite import TokenStore
from tokpulse_core.logging import get_logger
log = get_logger("refresh")
store = TokenStore(SETTINGS.token_store_path)

def refresh_if_needed():
    tok = store.get("tiktok_token")
    if not tok:
        log.warning("No token stored.")
        return
    expires_in = tok.get("expires_in", 3600)
    obtained_at = tok.get("obtained_at", int(time.time())-3600)
    remaining = (obtained_at + expires_in) - int(time.time())
    if remaining <= SETTINGS.token_refresh_buffer_min * 60:
        log.info("Refreshing token…")
        r = requests.post("https://business-api.tiktok.com/open_api/v1.3/oauth2/refresh_token/",
                          json={"app_id": SETTINGS.tiktok_app_id,"secret": SETTINGS.tiktok_app_secret,"refresh_token": tok.get("refresh_token","")},
                          timeout=30)
        r.raise_for_status()
        data = r.json().get("data", {})
        data["obtained_at"] = int(time.time())
        store.set("tiktok_token", data)
        log.info("Token refreshed.")
    else:
        log.info("Token valid for %ss", remaining)

if __name__ == "__main__":
    refresh_if_needed()
