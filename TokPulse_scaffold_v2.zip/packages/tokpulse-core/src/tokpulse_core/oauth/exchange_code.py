import argparse, requests, time
from tokpulse_core.config import SETTINGS
from tokpulse_core.oauth.store_sqlite import TokenStore

p = argparse.ArgumentParser()
p.add_argument("--code", required=True)
a = p.parse_args()

store = TokenStore(SETTINGS.token_store_path)
r = requests.post("https://business-api.tiktok.com/open_api/v1.3/oauth2/access_token/",
                  json={"app_id": SETTINGS.tiktok_app_id, "secret": SETTINGS.tiktok_app_secret, "auth_code": a.code}, timeout=30)
r.raise_for_status()
data = r.json().get("data", {})
data["obtained_at"] = int(time.time())
store.set("tiktok_token", data)
print("Stored token.")
