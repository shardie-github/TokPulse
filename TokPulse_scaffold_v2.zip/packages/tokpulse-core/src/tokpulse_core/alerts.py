import json, requests
from tokpulse_core.config import SETTINGS
from tokpulse_core.logging import get_logger
log = get_logger("alerts")

def _post(url: str, payload: dict):
    try:
        r = requests.post(url, json=payload, timeout=15)
        r.raise_for_status()
    except Exception as e:
        log.warning("Alert post failed: %s", e)

def discord(msg: str):
    if SETTINGS.discord_webhook_url:
        _post(SETTINGS.discord_webhook_url, {"content": msg})

def slack(msg: str):
    if SETTINGS.slack_webhook_url:
        _post(SETTINGS.slack_webhook_url, {"text": msg})
