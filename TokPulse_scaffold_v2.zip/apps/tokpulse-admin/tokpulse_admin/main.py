from fastapi import FastAPI
import os, glob
from tokpulse_core.config import SETTINGS
from tokpulse_core.logging import get_logger

app = FastAPI(title="TokPulse Admin v2")
log = get_logger("admin")

@app.get("/health")
def health():
    return {"ok": True, "tz": SETTINGS.tz}

@app.get("/exports")
def exports():
    files = sorted(glob.glob(os.path.join(SETTINGS.export_dir, "*")))
    return {"count": len(files), "files": files}

@app.get("/config")
def cfg():
    return {"warehouse": SETTINGS.warehouse_backend, "export_dir": SETTINGS.export_dir}

@app.get("/metrics")
def metrics():
    # simple file count metrics
    files = len(glob.glob(os.path.join(SETTINGS.export_dir, "*.csv")))
    return {"export_csv_count": files}
